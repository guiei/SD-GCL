import torch
import argparse
import random
import numpy as np
import scipy.sparse as sp
from networks import Model, GAT
from utils import load_dataset, augment, construct_graph, spec_clustering
from eval import label_classification
from torch_sparse import SparseTensor
from torch_geometric.utils import to_undirected, add_self_loops
# from utils11 import edgemask_um, edgemask_dm, do_edge_split_nc
parser = argparse.ArgumentParser()
parser.add_argument('--dataset', type=str, default='blockchain', help='dataset')
parser.add_argument('--log_dir', type=str, default='./log/', help='./log/')
parser.add_argument('--seed', type=int, default=123, help='seed')
parser.add_argument('--output', type=int, default=1024, help='output size')
parser.add_argument('--hidden_dim', type=int, default=1024, help='hidden size')
parser.add_argument('--lr', type=float, default=0.0001, help='learning rate')
parser.add_argument('--weight_decay', type=float, default=5e-5, help='weight decay')
parser.add_argument('--epochs', type=int, default=1000, help='maximum number of epochs')
parser.add_argument('--cluster', type=int, default=50, help='numbers of cluster')
parser.add_argument('--num_neighbors', type=int, default=100, help='numbers of neighbors in every cluster')
args = parser.parse_args()


random.seed(args.seed)
torch.manual_seed(args.seed)
torch.cuda.manual_seed(args.seed)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

datasets = load_dataset(args.dataset, './dataset/')
data = datasets
args.num_features = data.num_features


edge_index = data.edge_index.cpu().numpy()
adj_csr = sp.coo_matrix((np.ones(edge_index.shape[1]), (edge_index[0], edge_index[1])), shape=(data.num_nodes, data.num_nodes)).tocsr()
# adj_csr = sp.coo_matrix((np.ones(edge_index.shape[1]), (edge_index[0], edge_index[1])), shape=(19717,19717)).tocsr()

centers = spec_clustering(adj_csr, args.cluster, batch_size = 2000,dataset = args.dataset)
new_edge_index, new_centers, node_indices = construct_graph(data, centers, args.num_neighbors) 

data = data.to(device)
sub_x = data.x[node_indices]
new_edge_index = new_edge_index.to(device)
new_centers = new_centers.to(device)
encoder = GAT(args).to(device)
model = Model(encoder, args.output, args.output, tau=0.5,hard_weight=2.0).to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
model.train()

print(f'New number of nodes: {sub_x.shape[0]}')
print(f'New number of edges: {new_edge_index.shape[1]}')

for epoch in range(args.epochs):
    model.train()
    optimizer.zero_grad()
    
    sub_aug_x = augment(sub_x, new_centers)
    
    z1 = model(sub_x, new_edge_index) # original view
    z2 = model(sub_aug_x, new_edge_index) # augmented view
    
    loss = model.loss(z1, z2, new_centers)
    loss.backward()
    optimizer.step()
    
with torch.no_grad():
    emb = model(data.x, data.edge_index)

result = label_classification(emb, data.y, ratio=0.1)


print('-----------------')

