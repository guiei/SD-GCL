import torch
import torch.nn.functional as F
from torch_geometric.nn import GATConv

class GAT(torch.nn.Module):
    def __init__(self, args, heads=4):
        super(GAT, self).__init__()
        # 使用 GATConv，concat=False 表示对多头结果求平均，保持输出维度为 args.output
        # 如果 concat=True，输出维度会变为 args.output * heads，需要调整后续层
        self.conv1 = GATConv(args.num_features, args.output, heads=heads, concat=False, bias=True)
        self.prelu = torch.nn.PReLU(args.output)

    def forward(self, x, edge_index):
        z = self.conv1(x, edge_index)
        z = self.prelu(z)
        return z

class Model(torch.nn.Module):
    def __init__(self, encoder: GAT, num_hidden: int, num_proj_hidden: int,
                 tau: float = 0.5,hard_weight:float = 2.0):
        super(Model, self).__init__()
        self.encoder: GAT = encoder
        self.tau: float = tau

        self.hard_weight: float = hard_weight  # 难样本加权系数

        self.fc1 = torch.nn.Linear(num_hidden, num_proj_hidden)
        self.fc2 = torch.nn.Linear(num_proj_hidden, num_hidden)

    def forward(self, x: torch.Tensor,
                edge_index: torch.Tensor) -> torch.Tensor:
        return self.encoder(x, edge_index)

    def projection(self, z: torch.Tensor) -> torch.Tensor:
        z = F.elu(self.fc1(z))
        return self.fc2(z)

    def sim(self, z1: torch.Tensor, z2: torch.Tensor):
        z1 = F.normalize(z1)
        z2 = F.normalize(z2)
        return torch.mm(z1, z2.t())

    def semi_loss(self, z1: torch.Tensor, z2: torch.Tensor):
        f = lambda x: torch.exp(x / self.tau)
        refl_sim_raw = self.sim(z1, z1)
        between_sim_raw = self.sim(z1, z2)

        refl_sim = f(refl_sim_raw)
        between_sim = f(between_sim_raw)

        batch_size = z1.size(0)

        # --- 注意力加权逻辑开始 ---
        with torch.no_grad():
            # 1. 构建所有负样本的相似度矩阵
            # 这里的负样本包括：
            # (a) view1 中除了自己以外的所有节点 (Inter-negative)
            # (b) view2 中除了正样本对以外的所有节点 (Intra-negative)

            # 屏蔽掉 View1 自我相似 (对角线)
            mask_refl = torch.eye(batch_size, device=z1.device, dtype=torch.bool)
            refl_sim_for_att = refl_sim_raw.clone()
            refl_sim_for_att.masked_fill_(mask_refl, -1e9)  # 设为极小值以便Softmax忽略

            # 屏蔽掉 View2 正样本对 (对角线)
            # 注意：在InfoNCE分母中，通常包含正样本，但在计算负样本挖掘权重时，我们只关注负样本的困难程度
            between_sim_for_att = between_sim_raw.clone()
            between_sim_for_att.masked_fill_(mask_refl, -1e9)

            # 2. 拼接所有潜在负样本的相似度 [Batch, 2*Batch]
            all_neg_sims = torch.cat([refl_sim_for_att, between_sim_for_att], dim=1)

            # 3. 计算注意力分数 (Softmax)
            # 温度系数设小一点可以sharpen分布，突出难样本
            att_scores = F.softmax(all_neg_sims / 0.1, dim=1)

            # 4. 根据注意力分数生成权重
            # 原始权重为1.0。
            # 我们希望难样本的权重增加。
            # 乘以 (2 * batch_size) 是为了让权重的均值维持在 hard_weight 附近，而不是被 1/N 稀释
            dynamic_weights = 1.0 + (self.hard_weight * att_scores * (2 * batch_size))

            # 分割回两个部分
            w_refl = dynamic_weights[:, :batch_size]
            w_between = dynamic_weights[:, batch_size:]

            # 确保对角线（原本不参与负样本计算的部分）权重归位，不影响后续逻辑
            w_refl.masked_fill_(mask_refl, 1.0)
            # between的对角线是正样本，通常保持权重1.0即可
            w_between.masked_fill_(mask_refl, 1.0)

            # --- 应用权重 ---
        # 权重应用于分母中的 exp() 项
        weighted_refl_sim = refl_sim * w_refl
        weighted_between_sim = between_sim * w_between

        # 计算分母：加权后的 sum(refl) + sum(between) - 自身对角线
        # 注意：subtract refl_sim.diag() 是因为上面加权时 w_refl 对角线设为了1，
        # 所以 weighted_refl_sim.diag() 等于 refl_sim.diag() (即 exp(1/tau))，需要减去
        denominator = weighted_refl_sim.sum(1) + weighted_between_sim.sum(1) - weighted_refl_sim.diag()

        return -torch.log(between_sim.diag() / denominator)

    def loss(self, z1: torch.Tensor, z2: torch.Tensor, centers: torch.Tensor,
             mean: bool = True):
        h1 = self.projection(z1[centers])
        h2 = self.projection(z2[centers])

        l1 = self.semi_loss(h1, h2)
        l2 = self.semi_loss(h2, h1)

        ret = (l1 + l2) * 0.5
        ret = ret.mean() if mean else ret.sum()

        return ret
    # def sim(self, z1: torch.Tensor, z2: torch.Tensor):
    #     z1 = F.normalize(z1)
    #     z2 = F.normalize(z2)
    #     return torch.mm(z1, z2.t())
    #
    # def semi_loss(self, z1: torch.Tensor, z2: torch.Tensor):
    #     f = lambda x: torch.exp(x / self.tau)
    #     refl_sim = f(self.sim(z1, z1))
    #     between_sim = f(self.sim(z1, z2))
    #
    #     return -torch.log(
    #         between_sim.diag()
    #         / (refl_sim.sum(1) + between_sim.sum(1) - refl_sim.diag()))
    #
    # def loss(self, z1: torch.Tensor, z2: torch.Tensor, centers: torch.Tensor,
    #          mean: bool = True):
    #     h1 = self.projection(z1[centers])
    #     h2 = self.projection(z2[centers])
    #
    #     l1 = self.semi_loss(h1, h2)
    #     l2 = self.semi_loss(h2, h1)
    #
    #     ret = (l1 + l2) * 0.5
    #     ret = ret.mean() if mean else ret.sum()
    #
    #     return ret