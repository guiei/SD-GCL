import torch
import functools
import numpy as np
from GCL.eval.logistic_regression import LREvaluator
from GCL.eval.eval import get_split

from sklearn.metrics import precision_score, accuracy_score, normalized_mutual_info_score, adjusted_rand_score, f1_score


def repeat(n_times):
    def decorator(f):
        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            results = [f(*args, **kwargs) for _ in range(n_times)]
            statistics = {}
            for key in results[0].keys():
                values = [r[key] for r in results]
                statistics[key] = {
                    'mean': np.mean(values),
                    'std': np.std(values)}
            print_statistics(statistics, f.__name__)
            return statistics
        return wrapper
    return decorator

def prob_to_one_hot(y_pred):
    ret = np.zeros(y_pred.shape, bool)
    indices = np.argmax(y_pred, axis=1)
    for i in range(y_pred.shape[0]):
        ret[i][indices[i]] = True
    return ret

def print_statistics(statistics, function_name):
    print(f'(E) | {function_name}:', end=' ')
    for i, key in enumerate(statistics.keys()):
        mean = statistics[key]['mean']
        std = statistics[key]['std']
        print(f'{key}={mean:.4f}+-{std:.4f}', end='')
        if i != len(statistics.keys()) - 1:
            print(',', end=' ')
        else:
            print()
            
def label_classification1(embeddings, y, test_repeat = 3):
    r= torch.zeros(test_repeat)
    for num in range(test_repeat):
        split = get_split(embeddings.shape[0], train_ratio = 0.6, test_ratio = 0.3)
        logreg = LREvaluator(num_epochs=1000)
        result = logreg.evaluate(embeddings, y, split)
        r[num]= result['micro_f1']
    print('mean:',str(r.mean()),'std:', str(r.std()))
    return r.mean(), r.std()
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, normalized_mutual_info_score, adjusted_rand_score

def label_classification(embeddings, y, ratio=0.8, test_repeat=2, target_class=2):
    res = label_classification1(embeddings, y, test_repeat=2)
    acc_results = torch.zeros(test_repeat)
    nmi_results = torch.zeros(test_repeat)
    ari_results = torch.zeros(test_repeat)
    precision_results = torch.zeros(test_repeat)
    f1_target_results = torch.zeros(test_repeat)  # 存储目标类别的F1-score

    for num in range(test_repeat):
        split = get_split(embeddings.shape[0], train_ratio=0.6, test_ratio=0.3)
        train_mask = split['train']
        test_mask = split['test']

        # 确保标签是1D格式
        y_train = y[train_mask]
        if y_train.dim() > 1:
            y_train = torch.argmax(y_train, dim=1)

        # 训练逻辑回归分类器
        clf = LogisticRegression(max_iter=1000, multi_class='auto', solver='lbfgs')
        clf.fit(embeddings[train_mask].detach().cpu().numpy(), y_train.cpu().numpy())

        # 预测测试集标签
        y_pred = clf.predict(embeddings[test_mask].detach().cpu().numpy())

        # 准备真实测试标签
        y_test = y[test_mask]
        if y_test.dim() > 1:
            y_test = torch.argmax(y_test, dim=1)
        y_test = y_test.cpu().numpy()

        # 计算常规指标
        acc = accuracy_score(y_test, y_pred)
        nmi = normalized_mutual_info_score(y_test, y_pred)
        ari = adjusted_rand_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred, average='weighted')

        # 计算目标类别的F1-score
        # 将标签二值化：目标类别为1，其他类别为0
        y_test_binary = (y_test == target_class).astype(int)
        y_pred_binary = (y_pred == target_class).astype(int)
        f1_target = f1_score(y_test_binary, y_pred_binary)

        acc_results[num] = acc
        nmi_results[num] = nmi
        ari_results[num] = ari
        precision_results[num] = precision
        f1_target_results[num] = f1_target  # 存储目标类别的F1

    print('ACC mean: {:.4f}, std: {:.4f}'.format(acc_results.mean(), acc_results.std()))
    print('NMI mean: {:.4f}, std: {:.4f}'.format(nmi_results.mean(), nmi_results.std()))
    print('ARI mean: {:.4f}, std: {:.4f}'.format(ari_results.mean(), ari_results.std()))
    print('Precision mean: {:.4f}, std: {:.4f}'.format(precision_results.mean(), precision_results.std()))
    print(f'F1-score (class {target_class}) mean: {f1_target_results.mean():.4f}, std: {f1_target_results.std():.4f}')

    return {
        'acc': {'mean': acc_results.mean().item(), 'std': acc_results.std().item()},
        'nmi': {'mean': nmi_results.mean().item(), 'std': nmi_results.std().item()},
        'ari': {'mean': ari_results.mean().item(), 'std': ari_results.std().item()},
        'f1_target': {  # 返回目标类别的F1指标
            'mean': f1_target_results.mean().item(),
            'std': f1_target_results.std().item(),
            'target_class': target_class
        }
    }
# def label_classification(embeddings, y, ratio=0.8, test_repeat=2):
#     res = label_classification1(embeddings, y, test_repeat=5)
#     acc_results = torch.zeros(test_repeat)
#     nmi_results = torch.zeros(test_repeat)
#     ari_results = torch.zeros(test_repeat)
#     precision_results = torch.zeros(test_repeat)  # 新增：存储每次测试的precision
#
#     for num in range(test_repeat):
#         split = get_split(embeddings.shape[0], train_ratio=0.7, test_ratio=0.2)
#         train_mask = split['train']
#         test_mask = split['test']
#
#         # 确保标签是1D格式
#         y_train = y[train_mask]
#         if y_train.dim() > 1:
#             y_train = torch.argmax(y_train, dim=1)
#
#         # 训练逻辑回归分类器
#         clf = LogisticRegression(max_iter=1000, multi_class='auto', solver='lbfgs')
#         clf.fit(embeddings[train_mask].detach().cpu().numpy(), y_train.cpu().numpy())
#
#         # 预测测试集标签
#         y_pred = clf.predict(embeddings[test_mask].detach().cpu().numpy())
#
#         # 准备真实测试标签
#         y_test = y[test_mask]
#         if y_test.dim() > 1:
#             y_test = torch.argmax(y_test, dim=1)
#         y_test = y_test.cpu().numpy()
#
#         # 计算指标
#         acc = accuracy_score(y_test, y_pred)
#         nmi = normalized_mutual_info_score(y_test, y_pred)
#         ari = adjusted_rand_score(y_test, y_pred)
#         precision = precision_score(y_test, y_pred, average='weighted')
#
#         acc_results[num] = acc
#         nmi_results[num] = nmi
#         ari_results[num] = ari
#         precision_results[num] = precision  # 存储precision结果
#
#
#     print('ACC mean: {:.4f}, std: {:.4f}'.format(acc_results.mean(), acc_results.std()))
#     print('NMI mean: {:.4f}, std: {:.4f}'.format(nmi_results.mean(), nmi_results.std()))
#     print('ARI mean: {:.4f}, std: {:.4f}'.format(ari_results.mean(), ari_results.std()))
#     print('Precision mean: {:.4f}, std: {:.4f}'.format(precision_results.mean(), precision_results.std()))
#
#     return {
#         'acc': {'mean': acc_results.mean().item(), 'std': acc_results.std().item()},
#         'nmi': {'mean': nmi_results.mean().item(), 'std': nmi_results.std().item()},
#         'ari': {'mean': ari_results.mean().item(), 'std': ari_results.std().item()}
#     }